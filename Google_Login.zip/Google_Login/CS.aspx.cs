﻿using System;

using ASPSnippets.GoogleAPI;
using System.Web.Script.Serialization;

public partial class CS : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GoogleConnect.ClientId = "963816495555-a9tco393ediu9j1h6ccv4dvjlrp5pl7h.apps.googleusercontent.com";
        GoogleConnect.ClientSecret = "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";
        GoogleConnect.RedirectUri = Request.Url.AbsoluteUri.Split('?')[0];


     

        if (!this.IsPostBack)
        {
            string code = Request.QueryString["code"];
            if (!string.IsNullOrEmpty(code))
            {
                GoogleConnect connect = new GoogleConnect();
                string json = connect.Fetch("me", code);
                GoogleProfile profile = new JavaScriptSerializer().Deserialize<GoogleProfile>(json);
                lblId.Text = profile.Id;
                lblName.Text = profile.Name;
                lblEmail.Text = profile.Email;
                lblVerified.Text = profile.Verified_Email;
                imgProfile.ImageUrl = profile.Picture.ToString();
                lblimgProfile.Text = profile.Picture;
                pnlProfile.Visible = true;
                btnLogin.Enabled = false;
            }
        }
    }

    protected void Login(object sender, EventArgs e)
    {
        GoogleConnect.Authorize("profile", "email");
    }

    public class GoogleProfile
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Picture { get; set; }
        public string Email { get; set; }
        public string Verified_Email { get; set; }
    }
}